from setuptools import setup, find_packages

setup(
    name='py-calculator',
    version='1.0',
    author='Jad Elhachmi',
    description='A basic calculator module.',
    packages=find_packages(),
    install_requires=[
        'fractions',
    ],
)
