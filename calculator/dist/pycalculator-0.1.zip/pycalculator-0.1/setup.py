from setuptools import setup, find_packages

setup(
    name='pycalculator',
    version='0.1',
    packages=find_packages(),
    entry_points={
        'console_scripts': [
            'pycal = pycalculator.__main__:main'
        ]
    },
    install_requires=[
        'fractions',
    ],
    description='A simple calculator program.',
    url='https://github.com/yourusername/py-calculator'
)